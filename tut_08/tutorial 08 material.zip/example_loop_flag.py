flag = True
i = 1
while flag:
    print(i)
    if i == 5:
        flag = False
    i += 1
