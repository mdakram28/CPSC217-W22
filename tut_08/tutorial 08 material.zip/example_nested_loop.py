i=1
while i<=3 :
    print("i = {0}".format(i))
    j=1
    while j<=3:
        print("    j = {0}".format(j))
        j+=1
    i+=1
